import { NextRequest, NextResponse } from 'next/server';

const SIGHTENGINE_USER = process.env.SIGHTENGINE_API_USER!;
const SIGHTENGINE_SECRET = process.env.SIGHTENGINE_API_SECRET!;

export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const file = formData.get('image');

  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'No image provided' }, { status: 400 });
  }
  if (!file.type.startsWith('image/')) {
    return NextResponse.json({ error: 'Invalid file type' }, { status: 400 });
  }
  if (file.size > 10 * 1024 * 1024) {
    return NextResponse.json({ error: 'File too large (max 10MB)' }, { status: 400 });
  }

  const upstream = new FormData();
  upstream.append('media', file);
  upstream.append('models', 'genai');
  upstream.append('api_user', SIGHTENGINE_USER);
  upstream.append('api_secret', SIGHTENGINE_SECRET);

  const res = await fetch('https://api.sightengine.com/1.0/check.json', {
    method: 'POST',
    body: upstream,
  });

  if (!res.ok) {
    return NextResponse.json({ error: 'Detection service failed' }, { status: 502 });
  }

  const data = await res.json();
  const aiScore = data?.type?.ai_generated ?? null;

  if (aiScore === null) {
    return NextResponse.json({ error: 'Malformed response from detector' }, { status: 502 });
  }

  return NextResponse.json({
    aiScore,
    verdict: aiScore > 0.5 ? 'ai-generated' : 'likely-real',
  });
}
