'use client';
import { useState } from 'react';

export default function Home() {
  const [result, setResult] = useState<string>('');

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const form = new FormData();
    form.append('image', file);

    setResult('Checking...');
    const res = await fetch('/api/detect/image', { method: 'POST', body: form });
    const data = await res.json();
    setResult(JSON.stringify(data, null, 2));
  }

  return (
    <main style={{ padding: 40, fontFamily: 'monospace' }}>
      <h1>Image AI Detector</h1>
      <input type="file" accept="image/*" onChange={handleUpload} />
      <pre>{result}</pre>
    </main>
  );
}
