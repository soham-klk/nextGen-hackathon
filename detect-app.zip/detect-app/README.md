# AI Image Detector

Minimal Next.js app: upload an image, checks if it's AI-generated via Sightengine.

## Setup

```bash
npm install
cp .env.example .env.local
# fill in SIGHTENGINE_API_USER and SIGHTENGINE_API_SECRET in .env.local
npm run dev
```

Open http://localhost:3000 and upload an image.

## Push to your repo

```bash
git init
git add .
git commit -m "Add image AI-detection app"
git remote add origin <your-repo-url>
git push -u origin main
```

`.env.local` is gitignored — never commit real keys. Add them as secrets in your hosting platform (Vercel: Project Settings → Environment Variables).
